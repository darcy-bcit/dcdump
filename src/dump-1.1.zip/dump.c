#include "bits.h"
#include <ctype.h>
#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>


static void process_file(int fd, size_t width);
static void display(size_t position, char *position_format, uint8_t val);
static size_t number_of_digits(const off_t value);


int main(int argc, const char *argv[])
{
    int fd;
    off_t size;
    size_t width;

    if(argc > 1)
    {
        const char *file_name;
        struct stat st;

        file_name = argv[1];
        fd = open(file_name, O_RDONLY);
        
        if(fd == -1)
        {
            perror("open");
            
            return EXIT_FAILURE;
        }
        
        stat(file_name, &st);
        size = st.st_size;
    }
    else
    {
        fd = STDIN_FILENO;
        size = UINT_MAX;
    }
    
    width = number_of_digits(size);
    process_file(fd, width);
    
    if(argc > 1 && close(fd) == -1)
    {
        perror("close");
        
        return EXIT_FAILURE;
    }
    
    return EXIT_SUCCESS;
}

size_t number_of_digits(const off_t value)
{
    return value > 0 ? (size_t)log10((double)value) + 1 : 1;
}

static void process_file(int fd, size_t width)
{
    size_t position;
    ssize_t size;
    char position_format[1 + width + 2 + 1]; // eg:"%10ld\0"
    
    sprintf(position_format, "%%%ldld", width);
    position = 0;
    
    do
    {
        uint8_t byte;
        
        size = read(fd, &byte, 1);
        
        if(size == -1)
        {
            perror("read");
            exit(EXIT_FAILURE);
        }
        
        display(position, position_format, byte);
        position++;
    }
    while(size > 0); // 0 is end of file
}

static void display(size_t position, char *position_format, uint8_t byte)
{
    bool bits[8];
    char printable_bits[9];
    
    to_binary(byte, bits);
    to_printable_binary(bits, printable_bits);
    
    printf(position_format, position);
    printf(": ");
    
    if(isprint(byte))
    {
        printf("%c | ", byte);
    }
    else
    {
        printf("%c | ", ' ');
    }
    
    printf("%2X | ", byte);
    printf("%3d | ", byte);
    printf("%3o | ", byte);
    printf("%s\n", printable_bits);
}
